import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, portalStateTable } from "@workspace/db";
import {
  AttendanceSummary,
  GetAttendanceResponse,
  GetCourseParams,
  GetCourseResponse,
  GetDashboardQueryParams,
  GetDashboardResponse,
  GetGradesResponse,
  GetReportsOverviewResponse,
  GetScheduleQueryParams,
  GetScheduleResponse,
  ListActivityResponse,
  ListAssignmentsQueryParams,
  ListAssignmentsResponse,
  ListCoursesQueryParams,
  ListCoursesResponse,
  ListExaminationsResponse,
  ListRecommendationsQueryParams,
  ListRecommendationsResponse,
  ListStudentsQueryParams,
  ListStudentsResponse,
  RecordAttendanceBody,
  RecordGradeBody,
  RecordGradeResponse,
  SubmitAssignmentBody,
  SubmitAssignmentParams,
  SubmitAssignmentResponse,
} from "@workspace/api-zod";
import {
  getDashboardForRole,
  getRecommendationsForRole,
  seedPortalSnapshot,
  type PortalRole,
  type PortalSnapshot,
} from "../lib/portal-data";

const router: IRouter = Router();
const STATE_KEY = "default";

async function getSnapshot(): Promise<PortalSnapshot> {
  const [stored] = await db
    .select()
    .from(portalStateTable)
    .where(eq(portalStateTable.key, STATE_KEY));

  if (stored) return stored.payload as PortalSnapshot;

  const [created] = await db
    .insert(portalStateTable)
    .values({ key: STATE_KEY, payload: seedPortalSnapshot })
    .returning();
  return created.payload as PortalSnapshot;
}

async function saveSnapshot(snapshot: PortalSnapshot): Promise<PortalSnapshot> {
  const [saved] = await db
    .update(portalStateTable)
    .set({ payload: snapshot, updatedAt: new Date() })
    .where(eq(portalStateTable.key, STATE_KEY))
    .returning();
  return (saved?.payload as PortalSnapshot) ?? snapshot;
}

function asRole(value: string | undefined): PortalRole {
  return value === "teacher" || value === "admin" ? value : "student";
}

router.get("/dashboard", async (req, res): Promise<void> => {
  const parsed = GetDashboardQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const snapshot = await getSnapshot();
  res.json(GetDashboardResponse.parse(getDashboardForRole(snapshot, asRole(parsed.data.role))));
});

router.get("/activity", async (_req, res): Promise<void> => {
  const snapshot = await getSnapshot();
  res.json(ListActivityResponse.parse(snapshot.activity));
});

router.get("/courses", async (req, res): Promise<void> => {
  const parsed = ListCoursesQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { search, category, level, enrolled } = parsed.data;
  const snapshot = await getSnapshot();
  const normalizedSearch = search?.trim().toLowerCase();
  const courses = snapshot.courses.filter((course) => {
    const matchesSearch =
      !normalizedSearch ||
      `${course.code} ${course.title} ${course.department} ${course.instructor}`
        .toLowerCase()
        .includes(normalizedSearch);
    const matchesCategory = !category || course.department === category;
    const matchesLevel = !level || course.level === level;
    const matchesEnrollment = enrolled === undefined || course.enrolled === enrolled;
    return matchesSearch && matchesCategory && matchesLevel && matchesEnrollment;
  });
  res.json(ListCoursesResponse.parse(courses));
});

router.get("/courses/:id", async (req, res): Promise<void> => {
  const parsed = GetCourseParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const snapshot = await getSnapshot();
  const course = snapshot.courses.find((item) => item.id === parsed.data.id);
  if (!course) {
    res.status(404).json({ error: "Course not found" });
    return;
  }
  const detail = {
    ...course,
    assignments: snapshot.assignments.filter((assignment) => assignment.courseId === course.id),
  };
  res.json(GetCourseResponse.parse(detail));
});

router.post("/courses/:id/enroll", async (req, res): Promise<void> => {
  const parsed = GetCourseParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const snapshot = await getSnapshot();
  const course = snapshot.courses.find((item) => item.id === parsed.data.id);
  if (!course) {
    res.status(404).json({ error: "Course not found" });
    return;
  }
  course.enrolled = true;
  await saveSnapshot(snapshot);
  res.json({ courseId: course.id, enrolled: true, message: `You are now enrolled in ${course.title}.` });
});

router.get("/schedule", async (req, res): Promise<void> => {
  const parsed = GetScheduleQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const snapshot = await getSnapshot();
  const schedule = asRole(parsed.data.role) === "admin"
    ? snapshot.schedule.slice(0, 5)
    : snapshot.schedule;
  res.json(GetScheduleResponse.parse(schedule));
});

router.get("/assignments", async (req, res): Promise<void> => {
  const parsed = ListAssignmentsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const snapshot = await getSnapshot();
  const assignments = snapshot.assignments.filter((assignment) => {
    const statusMatches = !parsed.data.status || assignment.status === parsed.data.status;
    const courseMatches = parsed.data.courseId === undefined || assignment.courseId === parsed.data.courseId;
    return statusMatches && courseMatches;
  });
  res.json(ListAssignmentsResponse.parse(assignments));
});

router.post("/assignments/:id/submit", async (req, res): Promise<void> => {
  const params = SubmitAssignmentParams.safeParse(req.params);
  const body = SubmitAssignmentBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const snapshot = await getSnapshot();
  const assignment = snapshot.assignments.find((item) => item.id === params.data.id);
  if (!assignment) {
    res.status(404).json({ error: "Assignment not found" });
    return;
  }
  assignment.status = "submitted";
  await saveSnapshot(snapshot);
  res.json(SubmitAssignmentResponse.parse(assignment));
});

router.get("/attendance", async (_req, res): Promise<void> => {
  const snapshot = await getSnapshot();
  res.json(GetAttendanceResponse.parse(snapshot.attendance));
});

router.post("/attendance", async (req, res): Promise<void> => {
  const body = RecordAttendanceBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const snapshot = await getSnapshot();
  const existing = snapshot.attendance.byCourse.find((item) => item.course === body.data.course);
  if (existing) {
    existing.total += 1;
    if (body.data.present) existing.present += 1;
    existing.percentage = Math.round((existing.present / existing.total) * 100);
  }
  const totals = snapshot.attendance.byCourse.reduce(
    (acc, course) => ({ present: acc.present + course.present, total: acc.total + course.total }),
    { present: 0, total: 0 },
  );
  snapshot.attendance.present = totals.present;
  snapshot.attendance.overall = Math.round((totals.present / totals.total) * 100);
  if (!body.data.present) snapshot.attendance.absent += 1;
  await saveSnapshot(snapshot);
  res.json(GetAttendanceResponse.parse(snapshot.attendance));
});

router.get("/examinations", async (_req, res): Promise<void> => {
  const snapshot = await getSnapshot();
  res.json(ListExaminationsResponse.parse(snapshot.examinations));
});

router.get("/grades", async (_req, res): Promise<void> => {
  const snapshot = await getSnapshot();
  res.json(GetGradesResponse.parse(snapshot.grades));
});

router.post("/grades", async (req, res): Promise<void> => {
  const body = RecordGradeBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const snapshot = await getSnapshot();
  const course = snapshot.grades.courses.find((item) => item.course === body.data.course);
  if (course) {
    course.score = body.data.score;
    course.grade = body.data.score >= 90 ? "A" : body.data.score >= 85 ? "A-" : body.data.score >= 80 ? "B+" : "B";
  }
  await saveSnapshot(snapshot);
  res.json(RecordGradeResponse.parse(snapshot.grades));
});

router.get("/recommendations", async (req, res): Promise<void> => {
  const parsed = ListRecommendationsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const snapshot = await getSnapshot();
  res.json(ListRecommendationsResponse.parse(getRecommendationsForRole(snapshot, asRole(parsed.data.role))));
});

router.get("/students", async (req, res): Promise<void> => {
  const parsed = ListStudentsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const snapshot = await getSnapshot();
  const query = parsed.data.search?.trim().toLowerCase();
  const students = snapshot.students.filter((student) => !query || `${student.name} ${student.program} ${student.email}`.toLowerCase().includes(query));
  res.json(ListStudentsResponse.parse(students));
});

router.get("/reports/overview", async (_req, res): Promise<void> => {
  const snapshot = await getSnapshot();
  res.json(GetReportsOverviewResponse.parse(snapshot.reports));
});

export default router;