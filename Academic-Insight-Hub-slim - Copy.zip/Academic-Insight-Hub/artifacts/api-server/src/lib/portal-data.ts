export type PortalRole = "student" | "teacher" | "admin";

export type PortalSnapshot = {
  profile: {
    name: string;
    role: string;
    initials: string;
    program: string;
    email: string;
  };
  stats: Array<{ label: string; value: string; detail: string; tone: string }>;
  progress: Array<{ label: string; value: number }>;
  upcoming: Array<{
    id: number;
    title: string;
    subtitle: string;
    date: string;
    type: string;
    color: string;
  }>;
  insights: Array<{ title: string; body: string; tag: string; tone: string }>;
  activity: Array<{
    id: number;
    title: string;
    body: string;
    timestamp: string;
    type: string;
  }>;
  courses: Array<{
    id: number;
    code: string;
    title: string;
    department: string;
    instructor: string;
    level: string;
    credits: number;
    progress: number;
    students: number;
    color: string;
    schedule: string;
    enrolled: boolean;
    description: string;
    modules: Array<{ id: number; title: string; lessons: number; completed: number }>;
  }>;
  assignments: Array<{
    id: number;
    title: string;
    course: string;
    courseId: number;
    dueDate: string;
    status: string;
    score: number | null;
    maxScore: number;
    type: string;
  }>;
  schedule: Array<{
    id: number;
    day: string;
    start: string;
    end: string;
    title: string;
    room: string;
    instructor: string;
    color: string;
  }>;
  attendance: {
    overall: number;
    present: number;
    absent: number;
    late: number;
    byCourse: Array<{
      course: string;
      percentage: number;
      present: number;
      total: number;
      trend: string;
    }>;
  };
  examinations: Array<{
    id: number;
    title: string;
    course: string;
    date: string;
    time: string;
    room: string;
    status: string;
    score: number | null;
  }>;
  grades: {
    gpa: number;
    change: number;
    totalCredits: number;
    courses: Array<{
      course: string;
      code: string;
      grade: string;
      score: number;
      credits: number;
      trend: string;
    }>;
  };
  recommendations: Array<{
    id: number;
    title: string;
    body: string;
    subject: string;
    priority: string;
    action: string;
  }>;
  students: Array<{
    id: number;
    name: string;
    initials: string;
    program: string;
    year: string;
    attendance: number;
    gpa: number;
    risk: string;
    email: string;
  }>;
  reports: {
    students: number;
    averageGpa: number;
    attendance: number;
    atRisk: number;
    departments: Array<{ name: string; students: number; gpa: number; attendance: number }>;
    trend: Array<{ label: string; value: number }>;
  };
};

export const seedPortalSnapshot: PortalSnapshot = {
  profile: {
    name: "Aarav Mehta",
    role: "Student",
    initials: "AM",
    program: "BSc Computer Science · Year 2",
    email: "aarav.mehta@northstar.edu",
  },
  stats: [
    { label: "Current GPA", value: "3.72", detail: "+0.18 this term", tone: "violet" },
    { label: "Attendance", value: "92%", detail: "Above your target", tone: "mint" },
    { label: "Course progress", value: "68%", detail: "4 active courses", tone: "amber" },
    { label: "Assignments", value: "3", detail: "Due this week", tone: "coral" },
  ],
  progress: [
    { label: "Sep", value: 58 },
    { label: "Oct", value: 64 },
    { label: "Nov", value: 61 },
    { label: "Dec", value: 71 },
    { label: "Jan", value: 68 },
    { label: "Feb", value: 78 },
    { label: "Mar", value: 84 },
  ],
  upcoming: [
    { id: 1, title: "Machine Learning Foundations", subtitle: "Assignment 04 · 20 points", date: "Today", type: "assignment", color: "violet" },
    { id: 2, title: "Data Structures & Algorithms", subtitle: "Midterm examination", date: "Mar 18", type: "exam", color: "coral" },
    { id: 3, title: "Human Computer Interaction", subtitle: "Studio critique · Room 204", date: "Mar 20", type: "class", color: "mint" },
  ],
  insights: [
    { title: "Your strongest momentum is in algorithms", body: "Your last three assessments are trending 14% above your term average. Keep the rhythm going with one timed practice set this week.", tag: "On track", tone: "mint" },
    { title: "A small nudge for statistics", body: "Attendance is strong, but quiz scores dipped recently. A focused 25-minute review before Thursday's class could lift your next result.", tag: "Focus area", tone: "amber" },
  ],
  activity: [
    { id: 1, title: "Assignment graded", body: "You scored 18 / 20 in Data Structures & Algorithms", timestamp: "2 hours ago", type: "grade" },
    { id: 2, title: "New recommendation", body: "A study plan was created for your Statistics course", timestamp: "Yesterday", type: "insight" },
    { id: 3, title: "Attendance recorded", body: "Present in Human Computer Interaction", timestamp: "Yesterday", type: "attendance" },
    { id: 4, title: "Course milestone", body: "You completed module 3 in Machine Learning Foundations", timestamp: "Mar 10", type: "course" },
  ],
  courses: [
    {
      id: 1,
      code: "CS204",
      title: "Data Structures & Algorithms",
      department: "Computer Science",
      instructor: "Dr. Elena Rossi",
      level: "Intermediate",
      credits: 4,
      progress: 78,
      students: 42,
      color: "violet",
      schedule: "Mon & Wed · 10:00 AM",
      enrolled: true,
      description: "Build the problem-solving instincts behind efficient software. Explore trees, graphs, sorting, searching, and complexity through practical challenges.",
      modules: [
        { id: 1, title: "Complexity & Recursion", lessons: 5, completed: 5 },
        { id: 2, title: "Trees & Graphs", lessons: 7, completed: 6 },
        { id: 3, title: "Sorting & Searching", lessons: 6, completed: 3 },
      ],
    },
    {
      id: 2,
      code: "CS218",
      title: "Machine Learning Foundations",
      department: "Computer Science",
      instructor: "Prof. Marcus Chen",
      level: "Intermediate",
      credits: 4,
      progress: 64,
      students: 36,
      color: "mint",
      schedule: "Tue & Thu · 2:00 PM",
      enrolled: true,
      description: "An intuitive introduction to learning from data, from feature engineering to model evaluation and responsible deployment.",
      modules: [
        { id: 1, title: "Learning from Data", lessons: 4, completed: 4 },
        { id: 2, title: "Regression & Classification", lessons: 8, completed: 6 },
        { id: 3, title: "Model Evaluation", lessons: 5, completed: 1 },
      ],
    },
    {
      id: 3,
      code: "DS202",
      title: "Applied Statistics",
      department: "Data Science",
      instructor: "Dr. Nina Patel",
      level: "Foundational",
      credits: 3,
      progress: 58,
      students: 58,
      color: "amber",
      schedule: "Thu · 11:00 AM",
      enrolled: true,
      description: "Make confident decisions with data. Learn probability, inference, experimentation, and how to communicate uncertainty clearly.",
      modules: [
        { id: 1, title: "Probability in Practice", lessons: 6, completed: 5 },
        { id: 2, title: "Inference & Experiments", lessons: 7, completed: 4 },
        { id: 3, title: "Communicating Data", lessons: 4, completed: 1 },
      ],
    },
    {
      id: 4,
      code: "DES150",
      title: "Human Computer Interaction",
      department: "Design",
      instructor: "Prof. Jules Laurent",
      level: "Foundational",
      credits: 3,
      progress: 71,
      students: 28,
      color: "coral",
      schedule: "Fri · 9:00 AM",
      enrolled: true,
      description: "Study how people and technology shape each other, then turn research into interfaces that are useful, inclusive, and memorable.",
      modules: [
        { id: 1, title: "Research & Observation", lessons: 4, completed: 4 },
        { id: 2, title: "Interaction Patterns", lessons: 5, completed: 4 },
        { id: 3, title: "Prototype & Test", lessons: 6, completed: 3 },
      ],
    },
    {
      id: 5,
      code: "CS310",
      title: "Cloud Computing",
      department: "Computer Science",
      instructor: "Dr. Samuel Okafor",
      level: "Advanced",
      credits: 4,
      progress: 0,
      students: 31,
      color: "blue",
      schedule: "Mon · 3:00 PM",
      enrolled: false,
      description: "Understand the building blocks of reliable, scalable cloud systems and the tradeoffs behind modern distributed applications.",
      modules: [
        { id: 1, title: "Distributed Foundations", lessons: 6, completed: 0 },
        { id: 2, title: "Reliability & Scale", lessons: 7, completed: 0 },
      ],
    },
  ],
  assignments: [
    { id: 1, title: "Graph Traversal Visualizer", course: "Data Structures & Algorithms", courseId: 1, dueDate: "Mar 14, 2026", status: "due", score: null, maxScore: 20, type: "Project" },
    { id: 2, title: "Model Evaluation Notebook", course: "Machine Learning Foundations", courseId: 2, dueDate: "Mar 16, 2026", status: "in progress", score: null, maxScore: 25, type: "Notebook" },
    { id: 3, title: "Probability Problem Set", course: "Applied Statistics", courseId: 3, dueDate: "Mar 17, 2026", status: "due", score: null, maxScore: 15, type: "Problem set" },
    { id: 4, title: "Interface Critique", course: "Human Computer Interaction", courseId: 4, dueDate: "Mar 08, 2026", status: "graded", score: 18, maxScore: 20, type: "Critique" },
    { id: 5, title: "Recursion Practice", course: "Data Structures & Algorithms", courseId: 1, dueDate: "Mar 02, 2026", status: "graded", score: 19, maxScore: 20, type: "Practice" },
  ],
  schedule: [
    { id: 1, day: "Monday", start: "10:00", end: "11:30", title: "Data Structures & Algorithms", room: "Hawking 201", instructor: "Dr. Elena Rossi", color: "violet" },
    { id: 2, day: "Monday", start: "15:00", end: "16:30", title: "Cloud Computing", room: "Newton 104", instructor: "Dr. Samuel Okafor", color: "blue" },
    { id: 3, day: "Tuesday", start: "14:00", end: "15:30", title: "Machine Learning Foundations", room: "Turing 302", instructor: "Prof. Marcus Chen", color: "mint" },
    { id: 4, day: "Wednesday", start: "10:00", end: "11:30", title: "Data Structures & Algorithms", room: "Hawking 201", instructor: "Dr. Elena Rossi", color: "violet" },
    { id: 5, day: "Thursday", start: "11:00", end: "12:30", title: "Applied Statistics", room: "Curie 108", instructor: "Dr. Nina Patel", color: "amber" },
    { id: 6, day: "Thursday", start: "14:00", end: "15:30", title: "Machine Learning Foundations", room: "Turing 302", instructor: "Prof. Marcus Chen", color: "mint" },
    { id: 7, day: "Friday", start: "09:00", end: "10:30", title: "Human Computer Interaction", room: "Studio 4", instructor: "Prof. Jules Laurent", color: "coral" },
  ],
  attendance: {
    overall: 92,
    present: 46,
    absent: 2,
    late: 2,
    byCourse: [
      { course: "Data Structures & Algorithms", percentage: 95, present: 19, total: 20, trend: "up" },
      { course: "Machine Learning Foundations", percentage: 90, present: 18, total: 20, trend: "stable" },
      { course: "Applied Statistics", percentage: 88, present: 7, total: 8, trend: "down" },
      { course: "Human Computer Interaction", percentage: 100, present: 6, total: 6, trend: "up" },
    ],
  },
  examinations: [
    { id: 1, title: "Midterm Examination", course: "Data Structures & Algorithms", date: "Mar 18, 2026", time: "10:00 AM", room: "Hawking Hall", status: "upcoming", score: null },
    { id: 2, title: "Practical Assessment", course: "Machine Learning Foundations", date: "Mar 22, 2026", time: "2:00 PM", room: "Turing Lab", status: "upcoming", score: null },
    { id: 3, title: "Quiz 02", course: "Applied Statistics", date: "Mar 04, 2026", time: "11:00 AM", room: "Curie 108", status: "completed", score: 78 },
    { id: 4, title: "Studio Critique", course: "Human Computer Interaction", date: "Feb 27, 2026", time: "9:00 AM", room: "Studio 4", status: "completed", score: 92 },
  ],
  grades: {
    gpa: 3.72,
    change: 0.18,
    totalCredits: 14,
    courses: [
      { course: "Data Structures & Algorithms", code: "CS204", grade: "A", score: 91, credits: 4, trend: "up" },
      { course: "Machine Learning Foundations", code: "CS218", grade: "A-", score: 88, credits: 4, trend: "up" },
      { course: "Applied Statistics", code: "DS202", grade: "B+", score: 84, credits: 3, trend: "down" },
      { course: "Human Computer Interaction", code: "DES150", grade: "A", score: 93, credits: 3, trend: "up" },
    ],
  },
  recommendations: [
    { id: 1, title: "A 25-minute statistics reset", body: "Review confidence intervals and complete two practice questions before Thursday's class.", subject: "Applied Statistics", priority: "High impact", action: "Start focus session" },
    { id: 2, title: "Protect your algorithms momentum", body: "You are improving quickly. Try one timed graph traversal problem before the midterm.", subject: "Data Structures & Algorithms", priority: "Keep going", action: "Open practice set" },
    { id: 3, title: "Turn your HCI research into evidence", body: "Add one usability observation to your critique notes while the studio session is fresh.", subject: "Human Computer Interaction", priority: "Suggested", action: "View course notes" },
  ],
  students: [
    { id: 1, name: "Aarav Mehta", initials: "AM", program: "Computer Science", year: "Year 2", attendance: 92, gpa: 3.72, risk: "On track", email: "aarav.mehta@northstar.edu" },
    { id: 2, name: "Maya Singh", initials: "MS", program: "Data Science", year: "Year 2", attendance: 96, gpa: 3.91, risk: "On track", email: "maya.singh@northstar.edu" },
    { id: 3, name: "Noah Williams", initials: "NW", program: "Computer Science", year: "Year 3", attendance: 84, gpa: 3.18, risk: "Monitor", email: "noah.williams@northstar.edu" },
    { id: 4, name: "Sofia Garcia", initials: "SG", program: "Design", year: "Year 1", attendance: 78, gpa: 2.84, risk: "At risk", email: "sofia.garcia@northstar.edu" },
    { id: 5, name: "Ethan Brown", initials: "EB", program: "Computer Science", year: "Year 2", attendance: 89, gpa: 3.44, risk: "Monitor", email: "ethan.brown@northstar.edu" },
  ],
  reports: {
    students: 248,
    averageGpa: 3.38,
    attendance: 89,
    atRisk: 19,
    departments: [
      { name: "Computer Science", students: 96, gpa: 3.51, attendance: 91 },
      { name: "Data Science", students: 58, gpa: 3.43, attendance: 89 },
      { name: "Design", students: 47, gpa: 3.28, attendance: 87 },
      { name: "Business", students: 47, gpa: 3.21, attendance: 88 },
    ],
    trend: [
      { label: "Sep", value: 3.14 },
      { label: "Oct", value: 3.21 },
      { label: "Nov", value: 3.26 },
      { label: "Dec", value: 3.31 },
      { label: "Jan", value: 3.35 },
      { label: "Feb", value: 3.38 },
    ],
  },
};

export function getDashboardForRole(snapshot: PortalSnapshot, role: PortalRole) {
  if (role === "student") return snapshot;
  if (role === "teacher") {
    return {
      ...snapshot,
      profile: { name: "Dr. Elena Rossi", role: "Teacher", initials: "ER", program: "Computer Science Department", email: "elena.rossi@northstar.edu" },
      stats: [
        { label: "Active students", value: "42", detail: "+6 this term", tone: "violet" },
        { label: "Class attendance", value: "89%", detail: "Across 3 sections", tone: "mint" },
        { label: "To evaluate", value: "12", detail: "Submissions waiting", tone: "amber" },
        { label: "Upcoming exams", value: "2", detail: "In the next 14 days", tone: "coral" },
      ],
      insights: [
        { title: "Three students may need a check-in", body: "Attendance and recent scores dipped together in the Wednesday section. A short outreach this week could make a meaningful difference.", tag: "Early signal", tone: "coral" },
        { title: "Your class is strongest on graphs", body: "The cohort average rose 9% after the visual walkthrough. Consider carrying that approach into the next trees module.", tag: "Teaching insight", tone: "mint" },
      ],
    };
  }
  return {
    ...snapshot,
    profile: { name: "Priya Nair", role: "Administrator", initials: "PN", program: "Academic Operations", email: "priya.nair@northstar.edu" },
    stats: [
      { label: "Total students", value: "248", detail: "+12 this term", tone: "violet" },
      { label: "Average attendance", value: "89%", detail: "+2.4% this month", tone: "mint" },
      { label: "At-risk students", value: "19", detail: "7 need outreach", tone: "coral" },
      { label: "Active courses", value: "34", detail: "Across 4 departments", tone: "amber" },
    ],
    insights: [
      { title: "Design attendance needs attention", body: "Attendance in the Design department is 4 points below the university average. Review the comparative report for course-level context.", tag: "Admin insight", tone: "amber" },
      { title: "Progress is moving in the right direction", body: "Average GPA has climbed steadily for five months, led by Computer Science and Data Science cohorts.", tag: "Positive trend", tone: "mint" },
    ],
  };
}

export function getRecommendationsForRole(snapshot: PortalSnapshot, role: PortalRole) {
  if (role === "student") return snapshot.recommendations;
  if (role === "teacher") {
    return [
      { id: 11, title: "Reach out to the Wednesday section", body: "Three students show both lower attendance and lower assessment scores this month.", subject: "Data Structures & Algorithms", priority: "High impact", action: "Review students" },
      { id: 12, title: "Reuse the visual walkthrough", body: "The graph traversal lesson produced the strongest score lift in the cohort.", subject: "Teaching practice", priority: "Suggested", action: "Open course analytics" },
    ];
  }
  return [
    { id: 21, title: "Schedule a Design department review", body: "Attendance is trending below the university benchmark in two first-year courses.", subject: "Attendance", priority: "High impact", action: "View report" },
    { id: 22, title: "Celebrate the GPA lift", body: "Five months of steady improvement suggests the new academic support rhythm is working.", subject: "Academic progress", priority: "Positive trend", action: "Open analytics" },
  ];
}