---
name: Education portal build notes
description: Non-obvious workspace constraints encountered while bootstrapping the education portal.
---

OpenAPI integer schemas currently generate `zod.int()` calls that are incompatible with the workspace's installed Zod 3 runtime; use numeric schemas when generating API contracts unless the Zod toolchain is upgraded.

**Why:** The first contract generation passed Orval but failed the mandatory library typecheck because the generated validator used a Zod 4-only helper.

**How to apply:** When adding or changing API contracts in this workspace, run codegen immediately and confirm the generated validators typecheck before building dependent routes.

CSS data URIs in the generated Vite theme must percent-encode embedded quote characters.

**Why:** A texture rule containing literal SVG quotes caused Tailwind's Vite transform to fail and blanked the preview.

**How to apply:** Encode quotes inside inline SVG data URLs before putting them in CSS `url(...)` values.