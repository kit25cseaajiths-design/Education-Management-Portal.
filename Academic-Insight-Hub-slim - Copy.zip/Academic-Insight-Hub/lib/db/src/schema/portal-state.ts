import { jsonb, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const portalStateTable = pgTable("portal_state", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  payload: jsonb("payload").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const insertPortalStateSchema = createInsertSchema(portalStateTable).omit({
  id: true,
  updatedAt: true,
});

export type InsertPortalState = z.infer<typeof insertPortalStateSchema>;
export type PortalState = typeof portalStateTable.$inferSelect;